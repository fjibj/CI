\cp -f lxcfs /usr/bin/
mkdir -p /usr/lib64/lxcfs
\cp -f liblxcfs.so /usr/lib64/lxcfs/
\cp -f lxcfs.1 /usr/share/man/man1/
\cp -f lxcfs.service /usr/lib/systemd/system
mkdir -p /usr/share/lxc/config/common.conf.d
\cp -f 00-lxcfs.conf /usr/share/lxc/config/common.conf.d/
mkdir -p /usr/share/lxcfs
\cp -f lxc.mount.hook /usr/share/lxcfs/
\cp -f lxc.reboot.hook /usr/share/lxcfs/
\cp -f container_remount_lxcfs.sh /usr/local/bin/
mkdir -p /var/lib/lxc/lxcfs
systemctl daemon-reload
systemctl start lxcfs.service

